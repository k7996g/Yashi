package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountNotExistException;

public class AccountServiceImpl implements AccountService {
	AccountDao accountRef;

	public AccountServiceImpl() {
		accountRef = new AccountDaoImpl();
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws AccountNotExistException {

		return accountRef.getAccountDetails(mobileNo);
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws AccountNotExistException {

		return accountRef.rechargeAccount(mobileNo, rechargeAmount);
	}

}
