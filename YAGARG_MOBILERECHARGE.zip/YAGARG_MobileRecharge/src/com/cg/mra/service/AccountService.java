package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountNotExistException;

public interface AccountService {
	Account getAccountDetails(String mobileNo) throws AccountNotExistException;

	double rechargeAccount(String mobileNo, double rechargeAmount) throws AccountNotExistException;
}
