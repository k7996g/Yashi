package com.cg.mra.testDao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountNotExistException;

public class Testing {
	AccountDao daoRef;
	@Before
	public void Before()
	{
		daoRef=new AccountDaoImpl();
		System.out.println("Runs each time before each test case");
	}
@Test(expected=AccountNotExistException.class)
public void Test1Dao() throws AccountNotExistException
{
	daoRef.getAccountDetails("7895764778");
	
}
@Test
public void Test2Dao() throws AccountNotExistException 
{
	daoRef.getAccountDetails("7895764776");
	
}
	@Test
	public void Test3Dao() throws AccountNotExistException
	{
		daoRef.rechargeAccount("7895764776",10);
	}
	@Test(expected=AccountNotExistException.class)
	public void Test4Dao() throws AccountNotExistException
	{
		daoRef.rechargeAccount("7895764778",10);
	}
	
}
