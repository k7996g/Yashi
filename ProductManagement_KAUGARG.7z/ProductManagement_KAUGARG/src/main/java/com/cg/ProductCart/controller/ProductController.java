package com.cg.ProductCart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductCart.bean.ProductCart;
import com.cg.ProductCart.exception.IdNotFoundException;
import com.cg.ProductCart.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService service;

	@RequestMapping(path = "/Product", consumes = "application/json", produces = "application/json", method = RequestMethod.POST)
	public ProductCart createProduct(@RequestBody ProductCart product) {
		return service.createProduct(product);
	}

	@RequestMapping(path = "/Product", consumes = "application/json", produces = "application/json", method = RequestMethod.PUT)
	public ProductCart updateProduct(@RequestBody ProductCart product) {
		return service.updateProduct(product);
	}

	@RequestMapping(path = "/Product/{id}", produces = "application/json", method = RequestMethod.DELETE)
	public ProductCart deleteProduct(@PathVariable String id) throws IdNotFoundException {
		return service.deleteProduct(id);
	}

	@RequestMapping(path = "/Product", method = RequestMethod.GET)
	public List<ProductCart> viewProducts() {
		return service.viewProducts();
	}

	@RequestMapping(path = "/findProduct/{id}")
	public ProductCart findProduct(@PathVariable String id) throws IdNotFoundException {
		return service.findProduct(id);
	}

	@RequestMapping(path = "/updateById/{id}/{name}", method = RequestMethod.POST)
	public ProductCart updateById(@PathVariable String id, @PathVariable String name) throws IdNotFoundException {
		return service.updateById(id, name);
	}
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Id Not Exists")
	@ExceptionHandler({IdNotFoundException.class})
	public void handleException()
	{
		
	}
}
