package com.cg.ProductCart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ProductCart.bean.ProductCart;
import com.cg.ProductCart.exception.IdNotFoundException;
import com.cg.ProductCart.repo.IProductRepo;

@Transactional
@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo repo;

	@Override
	public ProductCart createProduct(ProductCart product) {

		return repo.createProduct(product);
	}

	@Override
	public ProductCart updateProduct(ProductCart product) {

		return repo.updateProduct(product);
	}

	@Override
	public ProductCart deleteProduct(String id) throws IdNotFoundException {

		return repo.deleteProduct(id);
	}

	@Override
	public List<ProductCart> viewProducts() {

		return repo.viewProducts();
	}

	@Override
	public ProductCart findProduct(String id) throws IdNotFoundException {

		return repo.findProduct(id);
	}

	@Override
	public ProductCart updateById(String id, String name) throws IdNotFoundException {

		return repo.updateById(id, name);
	}

}
