package com.cg.ProductCart.service;

import java.util.List;

import com.cg.ProductCart.bean.ProductCart;
import com.cg.ProductCart.exception.IdNotFoundException;

public interface IProductService {
	ProductCart createProduct(ProductCart product);

	ProductCart updateProduct(ProductCart product);

	ProductCart deleteProduct(String id) throws IdNotFoundException;

	List<ProductCart> viewProducts();

	ProductCart findProduct(String id) throws IdNotFoundException;

	ProductCart updateById(String id, String name) throws IdNotFoundException;
}
