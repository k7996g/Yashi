package com.cg.ProductCart.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ProductCart.bean.ProductCart;
import com.cg.ProductCart.exception.IdNotFoundException;

@Transactional
@Repository
public class ProductRepoImpl implements IProductRepo {
	@PersistenceContext
	EntityManager entity;

	@Override
	public ProductCart createProduct(ProductCart product) {
		entity.persist(product);
		entity.flush();
		return product;
	}

	@Override
	public ProductCart updateProduct(ProductCart product) {
		entity.merge(product);
		entity.flush();
		return product;
	}

	@Override
	public ProductCart deleteProduct(String id) throws IdNotFoundException {
		ProductCart product = entity.find(ProductCart.class, id);
		if (product == null)
			throw new IdNotFoundException("Id Not Exists");
		entity.remove(product);
		entity.flush();
		return product;
	}

	@Override
	public List<ProductCart> viewProducts() {
		TypedQuery<ProductCart> query = entity.createQuery("select product from ProductCart product",
				ProductCart.class);
		List<ProductCart> list = query.getResultList();
		return list;
	}

	@Override
	public ProductCart findProduct(String id) throws IdNotFoundException {
		ProductCart product = entity.find(ProductCart.class, id);
		if (product == null)
			throw new IdNotFoundException("Id Not Exists");
		return product;
	}

	@Override
	public ProductCart updateById(String id, String name) throws IdNotFoundException {
		ProductCart product = entity.find(ProductCart.class, id);
		if (product == null)
			throw new IdNotFoundException("Id Not Exists");
		else {
			product.setName(name);
			entity.merge(product);
			return product;

		}
	}
}
